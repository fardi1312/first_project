#include <gtk/gtk.h>

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////MASSOUD FARDI///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
on_MF_Ajouter_Election_button3_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MF_verf_checkbutton1_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_A_Afficher_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_MF_10CN_radiobutton_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_12CN_radiobutton_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_16CN_radiobutton_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_22CN_radiobutton_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_30CN_radiobutton_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_40CN_radiobutton_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_60CN_radiobutton_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_verf_checkbutton1_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_MF_Aficher_treeview_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_MF_Actualiser_afficher_button1_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_MF_Afficher_treeview_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Modifier_Election_button3_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_MF_R_MOD_Election_button3_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_MF_verf_MOD_checkbutton1_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_R_R_button_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_VERF_Sup_checkbutton_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MF_S_S_button_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Supprimer_Election_button3_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_R_multi_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_MF_Multi_R_button_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_Conseillers_button_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_TPE_button_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview_stat_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_MF_A_filechooser_button_file_set    (GtkFileChooserButton *filechooserbutton,
                                        gpointer         user_data);

void
on_MF_Annuler_b_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_MF_Afficher_window_activate_current_link
                                        (GtkLabel        *label,
                                        gpointer         user_data);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////AMINE BEN AFIA///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include <gtk/gtk.h>


void
on_button_valider1_AB_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);



void
on_button_retour_ges2_AB_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_valider2_AB_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_chercher_liste_AB_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_afficher_AB_clicked      (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_ajouter_AB_clicked       (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_modifier_AB_clicked      (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_supprimer_AB_clicked     (GtkWidget     *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_ges1_AB_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_ges4_AB_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_ges5_AB_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ges3_AB_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_valider3_AB_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_stat_liste_AB_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radio_nb_cand1_AB_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview_liste_AB_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_afficher_liste_AB_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton_liste_AB_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_liste2_AB_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_chercher_liste_AB_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_cherche_liste_AB_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_radio_nb_cand_AB_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_rech_retour_AB_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_stat_AB_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radio_nb_cand3_AB_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radio_nb_cand5_AB_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////ONS BEN OTHMEEEEN///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////



void
on_bv_ajouter_affiche_clicked          (GtkWidget *objet,
                                        gpointer         user_data);

void
on_bv_modifier_affiche_clicked         (GtkWidget  *objet,
                                        gpointer         user_data);

void
on_bv_supprimer_affiche_clicked        (GtkWidget  *objet,
                                        gpointer         user_data);

void
on_bv_retour_affiche_clicked           (GtkWidget  *objet,
                                        gpointer         user_data);

void
on_bv_help_affiche_clicked             (GtkWidget  *objet,
                                        gpointer         user_data);

void
on_bv_enregisster_ajouter_clicked      (GtkWidget *objet,
                                        gpointer         user_data);

void
on_bv_retour_ajouter_clicked           (GtkWidget  *objet,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);





void
on_bv_retour_ss_clicked    (GtkWidget *objet,
                                        gpointer         user_data);            

void
on_bv_okk_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bv_recherche_modif_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_bv_retour_modif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bv_enregister_modif_clicked         (GtkWidget *objet,
                                        gpointer         user_data);


void
on_bv_actualiser_affiche_clicked       (GtkWidget *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_cancelbutton2_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_okbutton2_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_clicked                (GtkWidget *objet,
                                        gpointer         user_data);

void
on_bv_retour_recherche_clicked         (GtkWidget *objet,
                                        gpointer         user_data);



void
on_bv_recherche_affiche_clicked        (GtkWidget *objet,
                                        gpointer         user_data);

void
on_button120_clicked                   (GtkButton       *button,
                                        gpointer         user_data);




void
on_bv_recherche_checkbutton2_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bv_recherche_final_clicked          (GtkWidget *objet,
                                        gpointer         user_data);



void
on_bv_stat_affiche_clicked             (GtkWidget *objet,
                                        gpointer         user_data);



void
on_bv_reload_stat_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_ons_okay_stat_clicked               (GtkWidget *objet,
                                        gpointer         user_data);

void
on_bv_retour_statistique_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_bv_chech_ajout_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_bv_chech_modifier_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_accueil_bv_clicked                  (GtkButton       *button,
                                        gpointer         user_data);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////ZIED BEN BRAHIM///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////


